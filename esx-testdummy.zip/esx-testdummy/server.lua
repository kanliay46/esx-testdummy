-- Sunucu tarafı - NPC'yi Spawn Etme ve Zırh Verme işlemleri

ESX = nil

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

-- NPC'yi spawn etmek
RegisterNetEvent('spawnNPC')
AddEventHandler('spawnNPC', function(x, y, z)
    local _source = source  -- Sunucu tarafında oyuncu ID'si

    -- NPC'yi spawn et ve istemciye yer bilgilerini gönder
    TriggerClientEvent('spawnNPC', _source, x, y, z)
end)

-- NPC'ye zırh ver
RegisterNetEvent('giveNPCArmor')
AddEventHandler('giveNPCArmor', function(armorAmount)
    local _source = source  -- Sunucu tarafında oyuncu ID'si

    -- Zırh ver işlemi istemciye gönderiliyor
    TriggerClientEvent('giveNPCArmor', _source, armorAmount)
end)

-- NPC öldüğünde veya belirli bir durumda sunucuda işlem yapılabilir
RegisterNetEvent('npcDead')
AddEventHandler('npcDead', function()
end)
